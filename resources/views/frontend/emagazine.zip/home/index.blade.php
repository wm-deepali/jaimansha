@extends('layouts.app')

@section('title', 'Home Page')

@section('content')

    {{-- Banner --}}
    @include('home.sections.banner')

    {{-- Introduction --}}
    @include('home.sections.introduction')

    {{-- Charity --}}
    @include('home.sections.charity')

    {{-- Donations --}}
    @include('home.sections.donations')

    @include('home.sections.normal')

    {{-- Events --}}
    @include('home.sections.events')

    @include('home.sections.charitytour')

    {{-- Team --}}
    @include('home.sections.team')

    {{-- Blogs --}}
    @include('home.sections.blogs')

@endsection
