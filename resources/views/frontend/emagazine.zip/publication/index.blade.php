<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from html.scriptfusions.com/givewell/main-html/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Jul 2025 11:24:32 GMT -->
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>   </title>
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicons/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicons/favicon-16x16.png" />
    <link rel="manifest" href="assets/images/favicons/site.webmanifest" />
    <meta name="description" content="givewell HTML 5 Template " />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&amp;display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&amp;display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{asset('admin/assets/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/animate.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/custom-animate.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/swiper.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/font-awesome-all.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/jarallax.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/jquery.magnific-popup.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/odometer.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/flaticon.css')}}">
    <link rel="stylesheet" href="{{asset('admin/assets/css/owl.carousel.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/owl.theme.default.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/nice-select.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/jquery-ui.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/vegas.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/aos.css')}}" />


    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/slider.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/footer.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/about.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/services.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/case.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/donars.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/benefits.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/event.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/video.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/team.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/testimonial.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/blog.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/get-app.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/feature.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/faq.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/helping-hand.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/gallery.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/donate.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/brand.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/join-one.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/contact.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/pricing.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/need-help.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/page-header.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/counter.css')}}" />

    <!-- template styles -->
    <link rel="stylesheet" href="{{asset('admin/assets/css/style.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/responsive.css')}}" />
</head>

<body class="custom-cursor">

    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

    <div class="preloader">
        <div class="preloader__image"></div>
    </div>
    <!-- /.preloader -->


    <div class="chat-icon"><button type="button" class="chat-toggler"><i class="fa fa-comment"></i></button></div>
    <!--Chat Popup-->
    <div id="chat-popup" class="chat-popup">
        <div class="popup-inner">
            <div class="close-chat"><i class="fa fa-times"></i></div>
            <div class="chat-form">
                <p>Please fill out the form below and we will get back to you as soon as possible.</p>
                <form action="https://html.scriptfusions.com/givewell/main-html/assets/inc/sendemail.php" method="POST" class="contact-form-validated">
                    <div class="form-group">
                        <input type="text" name="name" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" placeholder="Your Email" required>
                    </div>
                    <div class="form-group">
                        <textarea name="message" placeholder="Your Text"></textarea>
                    </div>
                    <div class="form-group message-btn">
                        <button type="submit" class="thm-btn">
                            Submit Now
                            <span class="icon-arrow-right"></span>
                            <i></i>
                        </button>
                    </div>
                    <div class="result"></div>
                </form>
            </div>
        </div>
    </div>


    <div class="page-wrapper">
       @include('layouts.header')
        <div class="stricky-header stricked-menu main-menu main-menu-three">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->

        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(assets/images/backgrounds/page-header-bg.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">
                    <h2>Publication</h2>
                    <div class="thm-breadcrumb__box">
                        <ul class="thm-breadcrumb list-unstyled">
                            <li><a href="index.html"><i class="fas fa-home"></i>Home</a></li>
                            <li><span class="icon-right-arrow-1"></span></li>
                            <li>Publication</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!--Page Header End-->



        <!--Services One Start -->
        <section class="services-one services-one--services">
            <div class="container">
                <div class="row">
                    <!--Services One Single Start-->
                    <div class="col-xl-4">
                        <div class="services-one__single">
                            <h3 class="services-one__title"><a href="kids-education.html">Kids
                                    Education</a></h3>
                            <div class="services-one__title-shape">
                                <img src="assets/images/shapes/services-one-title-shape.png" alt="">
                            </div>
                            <p class="services-one__text">We offer for tutorings, scholarships, and
                                workshop to help students...</p>
                            <div class="services-one__img-box">
                                <div class="services-one__img">
                                    <img src="assets/images/services/services-1-1.jpg" alt="">
                                </div>
                                <div class="services-one__icon-inner">
                                    <div class="services-one__icon">
                                        <span class="icon-mortarboard"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="services-one__read-more">
                                <a href="kids-education.html">Read More<span class="icon-arrow-right"></span></a>
                            </div>
                        </div>
                    </div>
                    <!--Services One Single End-->

                    <!--Services One Single Start-->
                    <div class="col-xl-4">
                        <div class="services-one__single">
                            <h3 class="services-one__title"><a href="pure-water.html">Pure Water</a>
                            </h3>
                            <div class="services-one__title-shape">
                                <img src="assets/images/shapes/services-one-title-shape.png" alt="">
                            </div>
                            <p class="services-one__text">We offer for tutorings, scholarships, and
                                workshop to help students...</p>
                            <div class="services-one__img-box">
                                <div class="services-one__img">
                                    <img src="assets/images/services/services-1-2.jpg" alt="">
                                </div>
                                <div class="services-one__icon-inner">
                                    <div class="services-one__icon">
                                        <span class="icon-mineral-water"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="services-one__read-more">
                                <a href="pure-water.html">Read More<span class="icon-arrow-right"></span></a>
                            </div>
                        </div>
                    </div>
                    <!--Services One Single End-->

                    <!--Services One Single Start-->
                    <div class="col-xl-4">
                        <div class="services-one__single">
                            <h3 class="services-one__title"><a href="medical-care.html">Medical Care</a>
                            </h3>
                            <div class="services-one__title-shape">
                                <img src="assets/images/shapes/services-one-title-shape.png" alt="">
                            </div>
                            <p class="services-one__text">We offer for tutorings, scholarships, and
                                workshop to help students...</p>
                            <div class="services-one__img-box">
                                <div class="services-one__img">
                                    <img src="assets/images/services/services-1-3.jpg" alt="">
                                </div>
                                <div class="services-one__icon-inner">
                                    <div class="services-one__icon">
                                        <span class="icon-doctor"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="services-one__read-more">
                                <a href="medical-care.html">Read More<span class="icon-arrow-right"></span></a>
                            </div>
                        </div>
                    </div>
                    <!--Services One Single End-->

                    <!--Services One Single Start-->
                    <div class="col-xl-4">
                        <div class="services-one__single">
                            <h3 class="services-one__title"><a href="kids-education.html">Kids
                                    Education</a></h3>
                            <div class="services-one__title-shape">
                                <img src="assets/images/shapes/services-one-title-shape.png" alt="">
                            </div>
                            <p class="services-one__text">We offer for tutorings, scholarships, and
                                workshop to help students...</p>
                            <div class="services-one__img-box">
                                <div class="services-one__img">
                                    <img src="assets/images/services/services-1-1.jpg" alt="">
                                </div>
                                <div class="services-one__icon-inner">
                                    <div class="services-one__icon">
                                        <span class="icon-mortarboard"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="services-one__read-more">
                                <a href="kids-education.html">Read More<span class="icon-arrow-right"></span></a>
                            </div>
                        </div>
                    </div>
                    <!--Services One Single End-->

                    <!--Services One Single Start-->
                    <div class="col-xl-4">
                        <div class="services-one__single">
                            <h3 class="services-one__title"><a href="pure-water.html">Pure Water</a>
                            </h3>
                            <div class="services-one__title-shape">
                                <img src="assets/images/shapes/services-one-title-shape.png" alt="">
                            </div>
                            <p class="services-one__text">We offer for tutorings, scholarships, and
                                workshop to help students...</p>
                            <div class="services-one__img-box">
                                <div class="services-one__img">
                                    <img src="assets/images/services/services-1-2.jpg" alt="">
                                </div>
                                <div class="services-one__icon-inner">
                                    <div class="services-one__icon">
                                        <span class="icon-mineral-water"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="services-one__read-more">
                                <a href="pure-water.html">Read More<span class="icon-arrow-right"></span></a>
                            </div>
                        </div>
                    </div>
                    <!--Services One Single End-->

                    <!--Services One Single Start-->
                    <div class="col-xl-4">
                        <div class="services-one__single">
                            <h3 class="services-one__title"><a href="medical-care.html">Medical Care</a>
                            </h3>
                            <div class="services-one__title-shape">
                                <img src="assets/images/shapes/services-one-title-shape.png" alt="">
                            </div>
                            <p class="services-one__text">We offer for tutorings, scholarships, and
                                workshop to help students...</p>
                            <div class="services-one__img-box">
                                <div class="services-one__img">
                                    <img src="assets/images/services/services-1-3.jpg" alt="">
                                </div>
                                <div class="services-one__icon-inner">
                                    <div class="services-one__icon">
                                        <span class="icon-doctor"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="services-one__read-more">
                                <a href="medical-care.html">Read More<span class="icon-arrow-right"></span></a>
                            </div>
                        </div>
                    </div>
                    <!--Services One Single End-->
                </div>
                <div class="blog-list__pagination text-center">
                    <ul class="pg-pagination list-unstyled">
                        <li class="count active"><a href="#">1</a></li>
                        <li class="count"><a href="#">2</a></li>
                        <li class="count"><a href="#">3</a></li>
                        <li class="next">
                            <a href="#" aria-label="Next"><i class="icon-arrow-right"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!--Services One End -->

        <!--Brand One Start-->
        <section class="brand-one">
            <div class="brand-one__inner">
                <div class="container">
                    <div class="brand-one__carousel owl-theme owl-carousel">
                        <!--Brand One Single-->
                        <div class="item">
                            <div class="brand-one__single">
                                <div class="brand-one__img">
                                    <img src="assets/images/brand/brand-1-1.png" alt="">
                                </div>
                                <div class="brand-one__img-2">
                                    <img src="assets/images/brand/brand-hover-1-1.png" alt="">
                                </div>
                            </div>
                        </div>
                        <!--Brand One Single-->
                        <div class="item">
                            <div class="brand-one__single">
                                <div class="brand-one__img">
                                    <img src="assets/images/brand/brand-1-2.png" alt="">
                                </div>
                                <div class="brand-one__img-2">
                                    <img src="assets/images/brand/brand-hover-1-1.png" alt="">
                                </div>
                            </div>
                        </div>
                        <!--Brand One Single-->
                        <div class="item">
                            <div class="brand-one__single">
                                <div class="brand-one__img">
                                    <img src="assets/images/brand/brand-1-3.png" alt="">
                                </div>
                                <div class="brand-one__img-2">
                                    <img src="assets/images/brand/brand-hover-1-1.png" alt="">
                                </div>
                            </div>
                        </div>
                        <!--Brand One Single-->
                        <div class="item">
                            <div class="brand-one__single">
                                <div class="brand-one__img">
                                    <img src="assets/images/brand/brand-1-4.png" alt="">
                                </div>
                                <div class="brand-one__img-2">
                                    <img src="assets/images/brand/brand-hover-1-1.png" alt="">
                                </div>
                            </div>
                        </div>
                        <!--Brand One Single-->
                        <div class="item">
                            <div class="brand-one__single">
                                <div class="brand-one__img">
                                    <img src="assets/images/brand/brand-1-5.png" alt="">
                                </div>
                                <div class="brand-one__img-2">
                                    <img src="assets/images/brand/brand-hover-1-1.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- If we need navigation buttons -->
                </div>
            </div>
        </section>
        <!--Brand One End-->

        <!--Benefits One Start-->
        <section class="benefits-one">
            <div class="benefits-one__inner">
                <div class="benefits-one__bg"
                    style="background-image: url(assets/images/backgrounds/benefits-one-bg.jpg);">
                    <div class="benefits-one__bg-shaddo"></div>
                </div>
                <div class="benefits-one__shape-1 float-bob-y">
                    <img src="assets/images/shapes/benefits-one-shape-1.png" alt="">
                </div>
                <div class="benefits-one__img-1">
                    <img src="assets/images/resources/benefits-one-img-1.png" alt="">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5">
                            <div class="benefits-one__left">
                                <div class="section-title text-left sec-title-animation animation-style2">
                                    <div class="section-title__tagline-box">
                                        <div class="section-title__tagline-icon">
                                            <i class="icon-like"></i>
                                        </div>
                                        <span class="section-title__tagline">Benefits of Giving</span>
                                    </div>
                                    <h2 class="section-title__title title-animation">Bring more meaning
                                        to your life</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-7">
                            <div class="benefits-one__right">
                                <div class="row">
                                    <!--Benefits One Single Start-->
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="benefits-one__single">
                                            <div class="benefits-one__single-inner">
                                                <h3 class="benefits-one__title"><a href="about.html">Reduce Your
                                                        Stress</a></h3>
                                                <div class="benefits-one__single-shape">
                                                    <img src="assets/images/shapes/benefits-one-single-shape-1.png"
                                                        alt="">
                                                </div>
                                                <p class="benefits-one__text">Perfectly simple & easy to distinguish
                                                    a free undertakes laborious...</p>
                                                <div class="benefits-one__icon">
                                                    <span class="icon-stress"></span>
                                                </div>
                                                <div class="benefits-one__arrow">
                                                    <a href="about.html"><span class="icon-arrow-right"></span></a>
                                                </div>
                                                <div class="benefits-one__single-shape-2"></div>
                                            </div>
                                            <div class="benefits-one__count-box">
                                                <div class="benefits-one__count-shape"></div>
                                                <div class="benefits-one__count"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Benefits One Single End-->
                                    <!--Benefits One Single Start-->
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="benefits-one__single">
                                            <div class="benefits-one__single-inner">
                                                <h3 class="benefits-one__title"><a href="about.html">Financial
                                                        Benefits</a></h3>
                                                <div class="benefits-one__single-shape">
                                                    <img src="assets/images/shapes/benefits-one-single-shape-1.png"
                                                        alt="">
                                                </div>
                                                <p class="benefits-one__text">Perfectly simple & easy to distinguish
                                                    a free undertakes laborious...</p>
                                                <div class="benefits-one__icon">
                                                    <span class="icon-growth"></span>
                                                </div>
                                                <div class="benefits-one__arrow">
                                                    <a href="about.html"><span class="icon-arrow-right"></span></a>
                                                </div>
                                                <div class="benefits-one__single-shape-2"></div>
                                            </div>
                                            <div class="benefits-one__count-box">
                                                <div class="benefits-one__count-shape"></div>
                                                <div class="benefits-one__count"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Benefits One Single End-->
                                    <!--Benefits One Single Start-->
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="benefits-one__single">
                                            <div class="benefits-one__single-inner">
                                                <h3 class="benefits-one__title"><a href="about.html">Familial
                                                        Benefits</a></h3>
                                                <div class="benefits-one__single-shape">
                                                    <img src="assets/images/shapes/benefits-one-single-shape-1.png"
                                                        alt="">
                                                </div>
                                                <p class="benefits-one__text">Perfectly simple & easy to distinguish
                                                    a free undertakes laborious...</p>
                                                <div class="benefits-one__icon">
                                                    <span class="icon-shape"></span>
                                                </div>
                                                <div class="benefits-one__arrow">
                                                    <a href="about.html"><span class="icon-arrow-right"></span></a>
                                                </div>
                                                <div class="benefits-one__single-shape-2"></div>
                                            </div>
                                            <div class="benefits-one__count-box">
                                                <div class="benefits-one__count-shape"></div>
                                                <div class="benefits-one__count"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Benefits One Single End-->
                                    <!--Benefits One Single Start-->
                                    <div class="col-xl-6 col-lg-6 col-md-6">
                                        <div class="benefits-one__single">
                                            <div class="benefits-one__single-inner">
                                                <h3 class="benefits-one__title"><a href="about.html">Improve Self
                                                        Esteem</a></h3>
                                                <div class="benefits-one__single-shape">
                                                    <img src="assets/images/shapes/benefits-one-single-shape-1.png"
                                                        alt="">
                                                </div>
                                                <p class="benefits-one__text">Perfectly simple & easy to distinguish
                                                    a free undertakes laborious...</p>
                                                <div class="benefits-one__icon">
                                                    <span class="icon-handshake"></span>
                                                </div>
                                                <div class="benefits-one__arrow">
                                                    <a href="about.html"><span class="icon-arrow-right"></span></a>
                                                </div>
                                                <div class="benefits-one__single-shape-2"></div>
                                            </div>
                                            <div class="benefits-one__count-box">
                                                <div class="benefits-one__count-shape"></div>
                                                <div class="benefits-one__count"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Benefits One Single End-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Benefits One End -->

        <!--Helping Hand Start -->
        <section class="helping-hand">
            <div class="helping-hand__top">
                <div class="helping-hand__top-wrap">
                    <div class="helping-hand__top-bg"
                        style="background-image: url(assets/images/backgrounds/helping-hand-top-bg.jpg);"></div>
                    <div class="container">
                        <div class="helping-hand__top-inner">
                            <div class="section-title text-left sec-title-animation animation-style2">
                                <div class="section-title__tagline-box">
                                    <div class="section-title__tagline-icon">
                                        <i class="icon-like"></i>
                                    </div>
                                    <span class="section-title__tagline">Helping Hand</span>
                                </div>
                                <h2 class="section-title__title title-animation">Services that Change live <br>
                                    What we Do</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="helping-hand__bottom">
                <div class="container">
                    <div class="helping-hand__bottom-inner">
                        <div class="helping-hand__bottom-bg"
                            style="background-image: url(assets/images/backgrounds/helping-hand-bottom-bg.jpg);"></div>
                        <div class="row">
                            <div class="col-xl-6 wow fadeInLeft" data-wow-delay="300ms">
                                <div class="helping-hand__single">
                                    <div class="helping-hand__icon">
                                        <span class="icon-team"></span>
                                    </div>
                                    <div class="helping-hand__single-inner">
                                        <div class="helping-hand__shape-2 float-bob-y">
                                            <img src="assets/images/shapes/helping-hand-shape-2.png" alt="">
                                        </div>
                                        <h4 class="helping-hand__title"><a href="about.html">Reliable Organization</a>
                                        </h4>
                                        <div class="helping-hand__shape-1">
                                            <img src="assets/images/shapes/helping-hand-shape-1.png" alt="">
                                        </div>
                                        <p class="helping-hand__text">In these time, let us strive to be active
                                            participants the acts of giving. Every effort
                                            count, together, we cancreate brighter
                                            more compassionate.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 wow fadeInRight" data-wow-delay="300ms">
                                <div class="helping-hand__single helping-hand__single--two">
                                    <div class="helping-hand__icon helping-hand__icon--two">
                                        <span class="icon-bonus"></span>
                                    </div>
                                    <div class="helping-hand__single-inner">
                                        <div class="helping-hand__shape-2 float-bob-y">
                                            <img src="assets/images/shapes/helping-hand-shape-2.png" alt="">
                                        </div>
                                        <h4 class="helping-hand__title"><a href="about.html">On time Distribution</a>
                                        </h4>
                                        <div class="helping-hand__shape-1">
                                            <img src="assets/images/shapes/helping-hand-shape-1.png" alt="">
                                        </div>
                                        <p class="helping-hand__text">In these time, let us strive to be active
                                            participants the acts of giving. Every effort
                                            count, together, we cancreate brighter
                                            more compassionate.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Helping Hand End -->

        <!--Faq One Start -->
        <section class="faq-one faq-two">
            <div class="container">
                <div class="section-title text-center sec-title-animation animation-style1">
                    <div class="section-title__tagline-box">
                        <div class="section-title__tagline-icon">
                            <i class="icon-like"></i>
                        </div>
                        <span class="section-title__tagline">Recently Ask Question</span>
                    </div>
                    <h2 class="section-title__title title-animation">People are frequently asking <br>
                        question from us</h2>
                </div>
                <div class="row">
                    <div class="col-xl-5 col-lg-5 wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                        <div class="faq-one__left">
                            <div class="faq-one__left-content">
                                <div class="faq-one__left-content-img-box">
                                    <div class="faq-one__left-content-img">
                                        <img src="assets/images/resources/faq-one-left-content-img.jpg" alt="">
                                    </div>
                                    <div class="faq-one__main-info">
                                        <p>Have any question</p>
                                        <h5> <span>Mail :</span> <a href="mailto:info@gmail.com">info@gmail.com</a></h5>
                                    </div>
                                </div>
                                <div class="faq-one__left-content-box">
                                    <div class="faq-one__left-content-shape-1 float-bob-x">
                                        <img src="assets/images/shapes/faq-one-left-content-shape-1.png" alt="">
                                    </div>
                                    <h3 class="faq-one__left-content-title">Get the Answer now</h3>
                                    <p class="faq-one__left-content-text">Join us in our mission uplift lives foster
                                        hope
                                        in our community. Whether you choose to volunteer,
                                        donate,or spread the word</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-7">
                        <div class="faq-one__right">
                            <div class="accrodion-grp faq-one-accrodion" data-grp-name="faq-one-accrodion-1">
                                <div class="accrodion">
                                    <div class="accrodion-title">
                                        <h4>What are the benefits of donating to charity?</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="faq-one__accrodion-content-bg"
                                            style="background-image: url(assets/images/backgrounds/faq-one-accordion-content-bg.jpg);">
                                        </div>
                                        <div class="inner">
                                            <p>Donating can provide a sense of fulfillment, help improve the lives of
                                                others, & may also offer tax deductions in some regions. In many
                                                countries,
                                                donations to registered charities are ..</p>
                                        </div><!-- /.inner -->
                                    </div>
                                </div>
                                <div class="accrodion  active">
                                    <div class="accrodion-title">
                                        <h4>How can I ensure a charity is legitimate? </h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="faq-one__accrodion-content-bg"
                                            style="background-image: url(assets/images/backgrounds/faq-one-accordion-content-bg.jpg);">
                                        </div>
                                        <div class="inner">
                                            <p>Donating can provide a sense of fulfillment, help improve the lives of
                                                others, & may also offer tax deductions in some regions. In many
                                                countries,
                                                donations to registered charities are ..</p>
                                        </div><!-- /.inner -->
                                    </div>
                                </div>
                                <div class="accrodion">
                                    <div class="accrodion-title">
                                        <h4>What types of volunteer opportunities are available?</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="faq-one__accrodion-content-bg"
                                            style="background-image: url(assets/images/backgrounds/faq-one-accordion-content-bg.jpg);">
                                        </div>
                                        <div class="inner">
                                            <p>Donating can provide a sense of fulfillment, help improve the lives of
                                                others, & may also offer tax deductions in some regions. In many
                                                countries,
                                                donations to registered charities are ..</p>
                                        </div><!-- /.inner -->
                                    </div>
                                </div>
                                <div class="accrodion">
                                    <div class="accrodion-title">
                                        <h4>How can I donate to a charity?</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="faq-one__accrodion-content-bg"
                                            style="background-image: url(assets/images/backgrounds/faq-one-accordion-content-bg.jpg);">
                                        </div>
                                        <div class="inner">
                                            <p>Donating can provide a sense of fulfillment, help improve the lives of
                                                others, & may also offer tax deductions in some regions. In many
                                                countries,
                                                donations to registered charities are ..</p>
                                        </div><!-- /.inner -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Faq One End -->

        <!--Site Footer Two Start-->
        <footer class="site-footer-two">
            @include('layouts.footer')
            <div class="site-footer-two__bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="site-footer-two__bottom-inner">
                                <div class="site-footer-two__copyright">
                                     <p class="site-footer-two__copyright-text">© 2025 <a href="#">Webmingo</a>
                                        All
                                        Rights Reserved.</p>
                                </div>
                                <div class="site-footer-two__bottom-menu-box">
                                    <ul class="list-unstyled site-footer-two__bottom-menu">
                                        <li><a href="about.html">Privacy Policy</a></li>
                                        <li><a href="about.html">Terms & Conditions</a></li>
                                        <li><a href="about.html">Customer Policy</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--Site Footer Two End-->




    </div><!-- /.page-wrapper -->


    <div class="mobile-nav__wrapper">
        <div class="mobile-nav__overlay mobile-nav__toggler"></div>
        <!-- /.mobile-nav__overlay -->
        <div class="mobile-nav__content">
            <span class="mobile-nav__close mobile-nav__toggler"><i class="fa fa-times"></i></span>

            <div class="logo-box">
                <a href="index.html" aria-label="logo image"><img src="assets/images/resources/logo-2.png" width="150"
                        alt="" /></a>
            </div>
            <!-- /.logo-box -->
            <div class="mobile-nav__container"></div>
            <!-- /.mobile-nav__container -->

            <ul class="mobile-nav__contact list-unstyled">
                <li>
                    <i class="fa fa-envelope"></i>
                    <a href="mailto:needhelp@packageName__.com">needhelp@givewell.com</a>
                </li>
                <li>
                    <i class="fas fa-phone"></i>
                    <a href="tel:666-888-0000">666 888 0000</a>
                </li>
            </ul><!-- /.mobile-nav__contact -->
            <div class="mobile-nav__top">
                <div class="mobile-nav__social">
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-facebook-square"></a>
                    <a href="#" class="fab fa-pinterest-p"></a>
                    <a href="#" class="fab fa-instagram"></a>
                </div><!-- /.mobile-nav__social -->
            </div><!-- /.mobile-nav__top -->



        </div>
        <!-- /.mobile-nav__content -->
    </div>
    <!-- /.mobile-nav__wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay search-toggler"></div>
        <!-- /.search-popup__overlay -->
        <div class="search-popup__content">
            <form action="#">
                <label for="search" class="sr-only">search here</label><!-- /.sr-only -->
                <input type="text" id="search" placeholder="Search Here..." />
                <button type="submit" aria-label="search submit" class="thm-btn">
                    <span class="fas fa-search"></span>
                </button>
            </form>
        </div>
        <!-- /.search-popup__content -->
    </div>
    <!-- /.search-popup -->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top">
        <span class="scroll-to-top__wrapper"><span class="scroll-to-top__inner"></span></span>
        <span class="scroll-to-top__text"> Go Back Top</span>
    </a>



    <script src="{{asset('admin/assets/js/jquery-latest.js')}}"></script>
    <script src="{{asset('admin/assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jarallax.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.ajaxchimp.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.appear.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/swiper.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.magnific-popup.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/odometer.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/wNumb.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/wow.js')}}"></script>
    <script src="{{asset('admin/assets/js/isotope.js')}}"></script>
    <script src="{{asset('admin/assets/js/owl.carousel.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery-ui.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.nice-select.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.circleType.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.fittext.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.lettering.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/vegas.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/aos.js')}}"></script>
    <script src="{{asset('admin/assets/js/marquee.min.js')}}"></script>




    <script src="{{asset('admin/assets/js/gsap/gsap.js')}}"></script>
    <script src="{{asset('admin/assets/js/gsap/ScrollTrigger.js')}}"></script>
    <script src="{{asset('admin/assets/js/gsap/SplitText.js')}}"></script>




    <!-- template js -->
    <script src="{{asset('admin/assets/js/script.js')}}"></script>
</body>


<!-- Mirrored from html.scriptfusions.com/givewell/main-html/services.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Jul 2025 11:24:33 GMT -->
</html>
