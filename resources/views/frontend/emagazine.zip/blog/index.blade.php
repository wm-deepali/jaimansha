@extends('layouts.blog')

@section('content')

   @include('blog.sections.blogpageheader')
   @include('blog.sections.blogpagecontent')

@endsection
