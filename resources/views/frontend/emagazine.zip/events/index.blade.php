@extends('layouts.events')

@section('content')


   @include('events.sections.eventsSection')

   @include('events.sections.eventsContent')

@endsection
