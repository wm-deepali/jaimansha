        <!--4. donation Case One Start -->
        <section class="case-one">
            <div class="case-one__bg-shape float-bob-y"
                style="background-image: url(admin/assets/images/shapes/case-one-bg-shape.png);">
            </div>
            <div class="container">
                <div class="section-title text-center sec-title-animation animation-style1">
                    <div class="section-title__tagline-box">
                        <div class="section-title__tagline-icon">
                            <i class="icon-like"></i>
                        </div>
                        <span class="section-title__tagline">Our Global Cases</span>
                    </div>
                    <h2 class="section-title__title title-animation">Spread joy with a Donation</h2>
                </div>
                <div class="case-one__main-tab-box case-one__tabs-box">
                    <ul class="case-one-tab-buttons case-one-tab-btns list-unstyled">
                        <li data-tab="#allcategory" class="p-tab-btn active-btn"><span>All Category</span>
                        </li>
                        <li data-tab="#healthfood" class="p-tab-btn"><span>Health & Food</span></li>
                        <li data-tab="#waterenvironment" class="p-tab-btn"><span>Water & Environment</span></li>
                        <li data-tab="#hungernutrition" class="p-tab-btn"><span>Hunger & Nutrition</span></li>
                    </ul>
                    <div class="p-tabs-content">
                        <div class="p-tab active-tab" id="allcategory">
                            <div class="case-one__inner">
                                <div class="case-one__carousel owl-theme owl-carousel">
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                </div>
                            </div>
                        </div>
                        <div class="p-tab" id="healthfood">
                            <div class="case-one__inner">
                                <div class="case-one__carousel owl-theme owl-carousel">
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                </div>
                            </div>
                        </div>
                        <div class="p-tab" id="waterenvironment">
                            <div class="case-one__inner">
                                <div class="case-one__carousel owl-theme owl-carousel">
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                </div>
                            </div>
                        </div>
                        <div class="p-tab" id="hungernutrition">
                            <div class="case-one__inner">
                                <div class="case-one__carousel owl-theme owl-carousel">
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-1.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$30,000 <span>/ $85,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="77%">
                                                                <div class="count-text">77%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Potable water
                                                            for villages
                                                            in
                                                            mozambique</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-2.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$28,000 <span>/ $60,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="65%">
                                                                <div class="count-text">65%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Nutrition</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Feed
                                                            nutritions meals to a
                                                            poor
                                                            rural child</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                    <!--Case One Single End-->
                                    <div class="item">
                                        <div class="case-one__single">
                                            <div class="case-one__img-box">
                                                <div class="case-one__img">
                                                    <img src="admin/assets/images/case/case-1-3.jpg" alt="">
                                                </div>
                                                <div class="case-one__raised-and-progress">
                                                    <div class="case-one__raised-box">
                                                        <div class="doller">
                                                            <span>$</span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Charity Raised</h3>
                                                            <p>$67,000 <span>/ $90,000</span></p>
                                                        </div>
                                                    </div>
                                                    <div class="case-one__progress">
                                                        <div class="bar">
                                                            <div class="bar-inner count-bar" data-percent="44%">
                                                                <div class="count-text">44%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="case-one__content">
                                                <div class="case-one__content-inner">
                                                    <p class="case-one__sub-title"># Health & Food</p>
                                                    <h3 class="case-one__title"><a href="donate-now.html">Help
                                                            differently abled
                                                            person to feel
                                                            strong confident</a></h3>
                                                    <p class="case-one__text">These activities offer opportunities to
                                                        connect with
                                                        others, build friendship & foster sense..</p>
                                                </div>
                                                <ul class="case-one__days-and-count list-unstyled">
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-calendar"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3>Days</h3>
                                                            <p>29 Days Left</p>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <span class="icon-team"></span>
                                                        </div>
                                                        <div class="content">
                                                            <h3><span class="odometer"
                                                                    data-count="50">00</span><span>+</span></h3>
                                                            <p>Suppoters</p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Case One Single Start-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        <!--Case One End -->
