   <footer class="site-footer">
       <div class="site-footer__shape-bg"
           style="background-image: url({{asset('admin/assets/images/shapes/site-footer-shape-bg.png')}});"></div>
       <div class="site-footer__shape-1 float-bob-y">
           <img src="{{asset('admin/assets/images/shapes/site-footer-shape-1.png')}}" alt="">
       </div>
       <div class="site-footer__top">
           <div class="container">
               <div class="site-footer__top-inner">
                   <div class="row">
                       <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="100ms">
                           <div class="footer-widget__about">
                               <div class="footer-widget__about-logo">
                                   <a href="index.html"><img src="{{asset('admin/assets/images/jaimansa-logo.png')}}" style="width: 150px;"
                                           alt=""></a>
                               </div>
                               <p class="footer-widget__about-text">Have questions that aren't <br> answered here?
                               </p>
                               <p class="footer-widget__about-number"><a href="tel:188822333">{{$footer->mobile}}</a></p>
                               <p class="footer-widget__about-time">Mon - Satday: 9am to 7pm</p>
                               <div class="footer-widget__about-email-box">
                                   <h4 class="footer-widget__about-email-title">Send via mail</h4>
                                   <p class="footer-widget__about-email"><a
                                           href="mailto:example@mail.com">{{$footer->email}}</a></p>
                               </div>
                           </div>
                       </div>
                       <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="200ms">
                           <div class="footer-widget__links">
                               <h4 class="footer-widget__title">Our Charity</h4>
                               <ul class="footer-widget__links-list list-unstyled">
                                   <li><a href="charity-donate.html">About Charity</a></li>
                                   <li><a href="contact.html">Contact Us</a></li>
                                   <li><a href="{{ route('frontend.blog.index')}}">Blog</a></li>
                                   <li><a href="blog.html">News & Updates</a></li>
                                   <li><a href="team.html">Meet Our Volunteers</a></li>
                                   <li><a href="about.html">Testimonials</a></li>
                                   <li><a href="events.html">Upcoming Events</a></li>
                                   <li><a href="contact.html">Join With Us</a></li>
                               </ul>
                           </div>
                       </div>
                       <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="300ms">
                           <div class="footer-widget__donars">
                               <h4 class="footer-widget__title">For Donars</h4>
                               <ul class="footer-widget__links-list list-unstyled">
                                   <li><a href="charity-donate.html">Donate</a></li>
                                   <li><a href="charity-donate.html">Crisis Relief Centre</a></li>
                                   <li><a href="medical-care.html">Refer a friend</a></li>
                                   <li><a href="money-raised.html">Donate Securities</a></li>
                                   <li><a href="money-raised.html">Fundraise</a></li>
                                   <li><a href="pure-water.html">Round up to Give</a></li>
                                   <li><a href="kids-education.html">Advocacy</a></li>
                               </ul>
                           </div>
                       </div>
                       <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="400ms">
                           <div class="footer-widget__payment">
                               <h4 class="footer-widget__title">Payment</h4>
                               <div class="footer-widget__payment-option">
                                   <p class="footer-widget__payment-option-text">Flexible payment options.</p>
                                   <div class="footer-widget__payment-option-list">
                                       <a href="#">
                                           <div class="footer-widget__payment-option-img">
                                               <img src="{{asset('admin/assets/images/resources/payment-option-img-1-1.png')}}"
                                                   alt="">
                                           </div>
                                       </a>
                                       <a href="#">
                                           <div class="footer-widget__payment-option-img">
                                               <img src="{{asset('admin/assets/images/resources/payment-option-img-1-2.png')}}"
                                                   alt="">
                                           </div>
                                       </a>
                                       <a href="#">
                                           <div class="footer-widget__payment-option-img">
                                               <img src="{{asset('admin/assets/images/resources/payment-option-img-1-3.png')}}"
                                                   alt="">
                                           </div>
                                       </a>
                                       <a href="#">
                                           <div class="footer-widget__payment-option-img">
                                               <img src="{{asset('admin/assets/images/resources/payment-option-img-1-4.png')}}"
                                                   alt="">
                                           </div>
                                       </a>
                                       <a href="#">
                                           <div class="footer-widget__payment-option-img">
                                               <img src="{{asset('admin/assets/images/resources/payment-option-img-1-5.png')}}"
                                                   alt="">
                                           </div>
                                       </a>
                                   </div>
                               </div>
                               <div class="footer-widget__social-box">
                                   <h4 class="footer-widget__social-title">Follow On</h4>
                                   <div class="footer-widget__social">
                                       <a href="{{ $footer->header->facebook ?? '#' }}" target="_blank" rel="noopener noreferrer">
                                           <span class="icon-facebook"></span>
                                       </a>
                                       <a href="{{ $footer->header->twitter ?? '#' }}" target="_blank" rel="noopener noreferrer">
                                           <span class="icon-twitter"></span>
                                       </a>
                                       <a href="{{ $footer->header->instagram ?? '#' }}" target="_blank" rel="noopener noreferrer">
                                           <span class="icon-instagram-logo"></span>
                                       </a>
                                       <a href="{{ $footer->header->youtube ?? '#' }}" target="_blank" rel="noopener noreferrer">
                                           <span class="icon-youtube"></span>
                                       </a>
                                   </div>

                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
