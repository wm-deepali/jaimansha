       <!--7.charity tourVideo One Start -->
        <section class="video-one">
            <div class="video-one__bg jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
                style="background-image: url(admin/assets/images/backgrounds/video-one-bg.jpg);"></div>
            <div class="container">
                <div class="video-one__inner">
                    <div class="video-one__single">
                        <div class="video-one__title-box">
                            <p>Charity Video Tour</p>
                            <h2>Social arts for behaviour <br> change approach</h2>
                        </div>
                        <div class="video-one__video-link">
                            <a href="https://www.youtube.com/watch?v=Get7rqXYrbQ" class="video-popup">
                                <div class="video-one__video-icon">
                                    <span class="icon-play"></span>
                                    <i class="ripple"></i>
                                </div>
                                <div class="video-one__round-text">
                                    <div class="video-one__curved-circle rotate-me">
                                        Watch the Video Watch the Video
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Video One End -->
