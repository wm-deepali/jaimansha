@extends('layouts.blog_details')

@section('content')


   @include('blog_details.sections.blogpagedetails')

      @include('blog_details.sections.blogsdetailscontent')

@endsection
