<!--Blog Details Start-->
<section class="blog-details">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-7">
                <div class="blog-details__left">
                    <div class="blog-details__img-box">
                        <div class="blog-details__img">
                            <img src="{{asset('admin/assets/images/blog/blog-details-img-1.jpg')}}" alt="">
                        </div>
                        <div class="blog-details__date">
                            <p>08<br><span>june</span></p>
                        </div>
                    </div>
                    <div class="blog-details__content">
                        <div class="blog-details__tag-and-client-box">
                            <div class="blog-details__tag">
                                <p><span class="icon-folder"></span>{{$blogs->category->category_name}}</p>
                            </div>
                            <div class="blog-details__client-box">
                                <div class="blog-details__client-img">
                                    <img src="{{asset('admin/assets/images/blog/blog-details-client-img.jpg')}}" alt="">
                                </div>
                                <p class="blog-details__client-name">{{$blogs->category->written_by}}</p>
                            </div>
                        </div>
                        <h3 class="blog-details__title-1">{{$blogs->title}}
                        </h3>
                        <div class="blog-details__shape-1">
                            <img src="{{asset('admin/assets/images/shapes/blog-details-shape-1.png')}}" alt="">
                        </div>
                        <p class="blog-details__text-1">{!!$blogs->detail_content!!}<br></p>
                        <div class="blog-details__quote-box">
                            <div class="blog-details__quote-icon">
                                <span class="icon-quote"></span>
                            </div>
                            <p class="blog-details__quote-text">{!! $blogs->short_description !!}</p>
                        </div>
                        <ul class="blog-details__points list-unstyled">
                            <li>
                                <div class="blog-details__points-shape"></div>
                                <p>{!! $blogs->meta_description !!}</p>
                            </li>
                        </ul>
                        <p class="blog-details__text-2">{!!$blogs->category->meta_description !!}</p>
                        <div class="blog-details__tag-and-social">
                            <div class="blog-details__tag-list">
                                <a href="#">Office</a>
                                <a href="#">Develop</a>
                                <a href="#">Build</a>
                            </div>
                            <div class="blog-details__social">
                                <a href="#"><span class="fab fa-facebook-f"></span></a>
                                <a href="#"><span class="fab fa-twitter"></span></a>
                                <a href="#"><span class="fab fa-instagram"></span></a>
                                <a href="#"><span class="fab fa-pinterest-p"></span></a>
                            </div>
                        </div>
                        <div class="blog-details__client-box-2">
                            <div class="blog-details__client-img-2">
                                <img src="{{asset('admin/assets/images/blog/blog-details-client-img-2.jpg')}}" alt="">
                            </div>
                            <div class="blog-details__client-content-2">
                                <h3>{{$blogs->category->written_by}}</h3>
                                <p>{{$blogs->title}}</p>
                                <div class="blog-details__client-social">
                                    <a href="#"><span class="fab fa-twitter"></span></a>
                                    <a href="#"><span class="fab fa-facebook-f"></span></a>
                                    <a href="#"><span class="fab fa-google-plus-g"></span></a>
                                    <a href="#"><span class="fab fa-pinterest-p"></span></a>
                                </div>
                            </div>
                        </div>
                        <div class="comment-one">
                            <h3 class="comment-one__title">Comments ( 2)</h3>
                            <div class="comment-one__single">
                                <div class="comment-one__image">
                                    <img src="{{asset('admin/assets/images/blog/comment-1-1.jpg')}}" alt="">
                                </div>
                                <div class="comment-one__content">
                                    <h3>Warner Joseph</h3>
                                    <p>Use your voice to promote causes you care about. Share information
                                        on social media, organize community events</p>
                                    <span>February 03. 2025</span>
                                    <div class="comment-one__btn-box">
                                        <a href="blog-details.html" class="comment-one__btn">reply</a>
                                    </div>
                                </div>
                            </div>
                            <div class="comment-one__single">
                                <div class="comment-one__image">
                                    <img src="{{asset('admin/assets/images/blog/comment-1-2.jpg')}}" alt="">
                                </div>
                                <div class="comment-one__content comment-one__content-2">
                                    <h3>Monyha Smith</h3>
                                    <p>Use your voice to promote causes you care about. Share information
                                        on social media, organize community events</p>
                                    <span>February 03. 2025</span>
                                    <div class="comment-one__btn-box">
                                        <a href="blog-details.html" class="comment-one__btn">reply</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="comment-form">
                            <h3 class="comment-form__title">Leave A comment </h3>
                            <form action="https://html.scriptfusions.com/givewell/main-html/assets/inc/sendemail.php"
                                class="comment-one__form contact-form-validated" novalidate="novalidate">
                                <div class="row">
                                    <div class="col-xl-6">
                                        <div class="comment-form__input-box">
                                            <input type="text" placeholder="Name" name="name">
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="comment-form__input-box">
                                            <input type="text" placeholder="Subject" name="name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="comment-form__input-box text-message-box">
                                            <textarea name="message" placeholder="Message"></textarea>
                                        </div>
                                        <div class="comment-form__btn-box">
                                            <button type="submit" class="thm-btn comment-form__btn">Leave a
                                                Comment<span class="icon-arrow-right"></span><i></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="result"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5">
                <div class="sidebar">
                    <div class="sidebar__single sidebar__search">
                        <form action="#" class="sidebar__search-form">
                            <input type="search" placeholder="Search here">
                            <button type="submit"><i class="icon-magnifying-glass"></i></button>
                        </form>
                    </div>
                    <div class="sidebar__single sidebar__all-category-box">
                        <div class="sidebar__title-box">
                            <div class="sidebar__title-shape"></div>
                            <h3 class="sidebar__title">Category</h3>
                        </div>
                        <div class="sidebar__all-category">
                            <ul class="sidebar__all-category-list list-unstyled">
                                @forelse($allCategories as $category)
                                <li>
                                    <a href="#">
                                        {{ $category->category_name }}
                                        <span class="icon-arrow-right"></span>
                                    </a>
                                </li>
                                @empty
                                <li><a href="#">No Category Found</a></li>
                                @endforelse
                            </ul>
                        </div>



                    </div>
                    <div class="sidebar__single sidebar__post">
                        <div class="sidebar__title-box">
                            <div class="sidebar__title-shape"></div>
                            <h3 class="sidebar__title">Recent Post</h3>
                        </div>
                        <div class="sidebar__post-inner">
                            <ul class="sidebar__post-list list-unstyled">
                                <li>
                                    <div class="sidebar__post-image">
                                        <img src="{{asset('admin/assets/images/blog/lp-1-1.jpg')}}" alt="">
                                    </div>
                                    <div class="sidebar__post-content">
                                        <h3>
                                            <a href="blog-details.html">Unlocking Generosity: The Impact of Your
                                                Contributions</a>
                                        </h3>
                                        <p class="sidebar__post-date">04 March 2025</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="sidebar__post-image">
                                        <img src="{{asset('admin/assets/images/blog/lp-1-2.jpg')}}" alt="">
                                    </div>
                                    <div class="sidebar__post-content">
                                        <h3>
                                            <a href="blog-details.html">Compassion in Action: How You Can Make a
                                                Difference</a>
                                        </h3>
                                        <p class="sidebar__post-date">15 April 2025</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="sidebar__post-image">
                                        <img src="{{asset('admin/assets/images/blog/lp-1-3.jpg')}}" alt="">
                                    </div>
                                    <div class="sidebar__post-content">
                                        <h3>
                                            <a href="blog-details.html">From Local Global: The Ripple Effects of
                                                Charity</a>
                                        </h3>
                                        <p class="sidebar__post-date">05 June 2025</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="sidebar__single sidebar__tags">
                        <div class="sidebar__title-box">
                            <div class="sidebar__title-shape"></div>
                            <h3 class="sidebar__title">Tags Cloud</h3>
                        </div>
                        <div class="sidebar__tags-box">
                            <div class="sidebar__tags-list">
                                <a href="#">Sponsorship</a>
                                <a href="#">Awarness</a>
                                <a href="#">Fundraising</a>
                                <a href="#">Donate</a>
                                <a href="#">Support</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Blog Details End-->
