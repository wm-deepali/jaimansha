<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from html.scriptfusions.com/givewell/main-html/kids-education.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Jul 2025 11:24:34 GMT -->
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> Kids Education ||  </title>
    <!-- favicons Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicons/apple-touch-icon.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicons/favicon-16x16.png" />
    <link rel="manifest" href="assets/images/favicons/site.webmanifest" />
    <meta name="description" content="givewell HTML 5 Template " />

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&amp;display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&amp;display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{asset('admin/assets/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/animate.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/custom-animate.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/swiper.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/font-awesome-all.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/jarallax.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/jquery.magnific-popup.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/odometer.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/flaticon.css')}}">
    <link rel="stylesheet" href="{{asset('admin/assets/css/owl.carousel.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/owl.theme.default.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/nice-select.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/jquery-ui.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/vegas.min.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/aos.css')}}" />


    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/slider.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/footer.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/about.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/services.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/case.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/donars.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/benefits.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/event.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/video.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/team.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/testimonial.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/blog.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/get-app.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/feature.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/faq.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/helping-hand.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/gallery.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/donate.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/brand.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/join-one.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/contact.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/pricing.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/need-help.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/page-header.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/module-css/counter.css')}}" />

    <!-- template styles -->
    <link rel="stylesheet" href="{{asset('admin/assets/css/style.css')}}" />
    <link rel="stylesheet" href="{{asset('admin/assets/css/responsive.css')}}" />
</head>

<body class="custom-cursor">

    <div class="custom-cursor__cursor"></div>
    <div class="custom-cursor__cursor-two"></div>

    <div class="preloader">
        <div class="preloader__image"></div>
    </div>
    <!-- /.preloader -->


    <div class="chat-icon"><button type="button" class="chat-toggler"><i class="fa fa-comment"></i></button></div>
    <!--Chat Popup-->
    <div id="chat-popup" class="chat-popup">
        <div class="popup-inner">
            <div class="close-chat"><i class="fa fa-times"></i></div>
            <div class="chat-form">
                <p>Please fill out the form below and we will get back to you as soon as possible.</p>
                <form action="https://html.scriptfusions.com/givewell/main-html/assets/inc/sendemail.php" method="POST" class="contact-form-validated">
                    <div class="form-group">
                        <input type="text" name="name" placeholder="Your Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" placeholder="Your Email" required>
                    </div>
                    <div class="form-group">
                        <textarea name="message" placeholder="Your Text"></textarea>
                    </div>
                    <div class="form-group message-btn">
                        <button type="submit" class="thm-btn">
                            Submit Now
                            <span class="icon-arrow-right"></span>
                            <i></i>
                        </button>
                    </div>
                    <div class="result"></div>
                </form>
            </div>
        </div>
    </div>


    <div class="page-wrapper">
         @include('layouts.header')

        <div class="stricky-header stricked-menu main-menu main-menu-three">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->

        <!--Page Header Start-->
        <section class="page-header">
            <div class="page-header__bg" style="background-image: url(assets/images/backgrounds/page-header-bg.jpg);">
            </div>
            <div class="container">
                <div class="page-header__inner">
                    <h2>Publication Details</h2>
                    <div class="thm-breadcrumb__box">
                        <ul class="thm-breadcrumb list-unstyled">
                            <li><a href="index.html"><i class="fas fa-home"></i>Home</a></li>
                            <li><span class="icon-right-arrow-1"></span></li>
                            <li>Publication</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!--Page Header End-->

        <!--Service Details Start-->
        <section class="service-details">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-7">
                        <div class="service-details__left">
                            <div class="service-details__img">
                                <img src="assets/images/services/service-details-img-3.jpg" alt="">
                            </div>
                            <div class="service-details__content">
                                <h3 class="service-details__title-1">Kids Education</h3>
                                <p class="service-details__text-1">We provide immediate support to individuals and
                                    families
                                    facing crisis situations. This includes food distribution,
                                    temporary shelter, and access to essential supplies.Our educational initiatives
                                    focus on
                                    empowering individuals
                                    through learning. We offer tutoring, scholarships, and workshops to help students
                                    and
                                    adults gain the skills they
                                    need for a brighter future.</p>
                                <p class="service-details__text-2">To help individuals achieve financial independence,
                                    we
                                    provide job training, resume workshops, and employment
                                    placement services. We partner with local businesses to connect our clients with job
                                    opportunities.We organize
                                    community events to foster connection.</p>
                                <ul class="service-details__points list-unstyled">
                                    <li>
                                        <div class="icon">
                                            <span class="icon-check"></span>
                                        </div>
                                        <p>Our advocacy efforts aim to raise awareness & influence policy change on
                                            issues
                                            affecting our community.</p>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <span class="icon-check"></span>
                                        </div>
                                        <p>We work tirelessly to ensure that every voice is heard and that necessary
                                            resources are accessible to all.</p>
                                    </li>
                                </ul>
                                <div class="service-details__video-img">
                                    <img src="assets/images/services/service-details-video-img-1.jpg" alt="">
                                    <div class="service-details__video-link">
                                        <a href="https://www.youtube.com/watch?v=Get7rqXYrbQ" class="video-popup">
                                            <div class="service-details__video-icon-inner">
                                                <div class="service-details__video-icon">
                                                    <span class="icon-play"></span>
                                                    <i class="ripple"></i>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <p class="service-details__text-3">Ready to start your next construction project?
                                    Contact Premier Construction Services today to schedule a
                                    consultation. Our friendly team here to answer your questions & provide you with a
                                    detailed estimate. Let us turn
                                    your construction dreams into reality! Making it clear and informative for potential
                                    clients.</p>
                                <div class="service-details__tab-box">
                                    <div class="service-details__main-tab-box tabs-box">
                                        <ul class="tab-buttons list-unstyled">
                                            <li data-tab="#specializations" class="tab-btn tab-btn-one">
                                                <span>Specializations</span></li>
                                            <li data-tab="#intelligence" class="tab-btn active-btn tab-btn-two">
                                                <span>Intelligence</span>
                                            </li>
                                            <li data-tab="#precautions" class="tab-btn tab-btn-two">
                                                <span>Precautions</span></li>
                                            <li data-tab="#supersupport" class="tab-btn tab-btn-two"><span>Super
                                                    Support</span></li>
                                        </ul>
                                        <div class="tabs-content">
                                            <!--tab-->
                                            <div class="tab" id="specializations">
                                                <div class="service-details__inner-content-box">
                                                    <p class="service-details__tab-text-1">Together, we can create a
                                                        brighter future. Join us in our mission to uplift lives and
                                                        foster hope in our community.
                                                        Whether you choose to volunteer, donate, or spread the word,
                                                        your support is vital in making lasting change
                                                        We are dedicated to making a tangible difference by providing
                                                        [specific services or support, e.g.,
                                                        food, education,</p>
                                                </div>
                                                <ul class="service-details__tab-points list-unstyled">
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">This text outlines
                                                            the services provided, highlights the benefits of choosing
                                                            the company</p>
                                                    </li>
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">And includes a call
                                                            to action, making it clear and informative for potential
                                                            clients.</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--tab-->
                                            <!--tab-->
                                            <div class="tab active-tab" id="intelligence">
                                                <div class="service-details__inner-content-box">
                                                    <p class="service-details__tab-text-1">Together, we can create a
                                                        brighter future. Join us in our mission to uplift lives and
                                                        foster hope in our community.
                                                        Whether you choose to volunteer, donate, or spread the word,
                                                        your support is vital in making lasting change
                                                        We are dedicated to making a tangible difference by providing
                                                        [specific services or support, e.g.,
                                                        food, education,</p>
                                                </div>
                                                <ul class="service-details__tab-points list-unstyled">
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">This text outlines
                                                            the services provided, highlights the benefits of choosing
                                                            the company</p>
                                                    </li>
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">And includes a call
                                                            to action, making it clear and informative for potential
                                                            clients.</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--tab-->
                                            <!--tab-->
                                            <div class="tab" id="precautions">
                                                <div class="service-details__inner-content-box">
                                                    <p class="service-details__tab-text-1">Together, we can create a
                                                        brighter future. Join us in our mission to uplift lives and
                                                        foster hope in our community.
                                                        Whether you choose to volunteer, donate, or spread the word,
                                                        your support is vital in making lasting change
                                                        We are dedicated to making a tangible difference by providing
                                                        [specific services or support, e.g.,
                                                        food, education,</p>
                                                </div>
                                                <ul class="service-details__tab-points list-unstyled">
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">This text outlines
                                                            the services provided, highlights the benefits of choosing
                                                            the company</p>
                                                    </li>
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">And includes a call
                                                            to action, making it clear and informative for potential
                                                            clients.</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--tab-->
                                            <!--tab-->
                                            <div class="tab" id="supersupport">
                                                <div class="service-details__inner-content-box">
                                                    <p class="service-details__tab-text-1">Together, we can create a
                                                        brighter future. Join us in our mission to uplift lives and
                                                        foster hope in our community.
                                                        Whether you choose to volunteer, donate, or spread the word,
                                                        your support is vital in making lasting change
                                                        We are dedicated to making a tangible difference by providing
                                                        [specific services or support, e.g.,
                                                        food, education,</p>
                                                </div>
                                                <ul class="service-details__tab-points list-unstyled">
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">This text outlines
                                                            the services provided, highlights the benefits of choosing
                                                            the company</p>
                                                    </li>
                                                    <li>
                                                        <div class="service-details__tab-points-shape"></div>
                                                        <p class="service-details__tab-points-text">And includes a call
                                                            to action, making it clear and informative for potential
                                                            clients.</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--tab-->
                                        </div>
                                    </div>
                                </div>
                                <h3 class="service-details__title-2">Creativity What You</h3>
                                <p class="service-details__text-4">Looking to update your existing space? Our remodeling
                                    and renovation services can breathe new life into your
                                    property. Whether it’s a kitchen makeover, a bathroom upgrade, or a complete home
                                    renovation, we provide inno
                                    vative solutions that enhance both the appearance and value of your property. With
                                    years of experience in the
                                    construction industry, our skilled professionals bring a wealth ...</p>
                                <p class="service-details__text-5">To help individuals achieve financial independence,
                                    we provide job training, resume workshops, and employment
                                    placement services. We partner with local businesses to connect our clients with job
                                    opportunities.</p>
                                <ul class="service-details__points-2 list-unstyled">
                                    <li>
                                        <div class="icon">
                                            <span class="icon-check"></span>
                                        </div>
                                        <p>With years of experience in the construction industry, our skilled
                                            professionals bring a wealth of knowledge.</p>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <span class="icon-check"></span>
                                        </div>
                                        <p>Your satisfaction is our top priority. We work closely with you to understand
                                            your needs and deliver results exceed.</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <div class="sidebar">
                            <div class="sidebar__single sidebar__search">
                                <form action="#" class="sidebar__search-form">
                                    <input type="search" placeholder="Search here">
                                    <button type="submit"><i class="icon-magnifying-glass"></i></button>
                                </form>
                            </div>
                            <div class="sidebar__single sidebar__all-category-box">
                                <div class="sidebar__title-box">
                                    <div class="sidebar__title-shape"></div>
                                    <h3 class="sidebar__title">Category</h3>
                                </div>
                                <div class="sidebar__all-category">
                                    <ul class="sidebar__all-category-list list-unstyled">
                                        <li>
                                            <a href="pure-water.html">Pure Water<span
                                                    class="icon-arrow-right"></span></a>
                                        </li>
                                        <li class="active">
                                            <a href="kids-education.html">Kids Education<span
                                                    class="icon-arrow-right"></span></a>
                                        </li>
                                        <li>
                                            <a href="medical-care.html">Medical Care<span
                                                    class="icon-arrow-right"></span></a>
                                        </li>
                                        <li>
                                            <a href="charity-donate.html">Charity Donate<span
                                                    class="icon-arrow-right"></span></a>
                                        </li>
                                        <li>
                                            <a href="money-raised.html">Money Raised<span
                                                    class="icon-arrow-right"></span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="sidebar__single sidebar__have-question">
                                <div class="sidebar__title-box">
                                    <div class="sidebar__title-shape"></div>
                                    <h3 class="sidebar__title">Have Your Question</h3>
                                </div>
                                <div class="sidebar__have-question-inner">
                                    <form class="contact-form-validated sidebar__have-question-form"
                                        action="https://html.scriptfusions.com/givewell/main-html/assets/inc/sendemail.php" method="post" novalidate="novalidate">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="have-question__input-box">
                                                    <div class="have-question__input-icon">
                                                        <span class="icon-user"></span>
                                                    </div>
                                                    <input type="text" name="name" placeholder="Name" required="">
                                                </div>
                                            </div>
                                            <div class="col-xl-12">
                                                <div class="have-question__input-box text-message-box">
                                                    <div class="have-question__input-icon">
                                                        <span class="icon-open-mail"></span>
                                                    </div>
                                                    <textarea name="message" placeholder="Your Message"></textarea>
                                                </div>
                                                <div class="have-question__btn-box">
                                                    <button type="submit" class="thm-btn have-question__btn">Submit
                                                        Now<span class="icon-arrow-right"></span><i></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="result"></div>
                                </div>
                            </div>
                            <div class="sidebar__single sidebar__download-box">
                                <div class="sidebar__title-box">
                                    <div class="sidebar__title-shape"></div>
                                    <h3 class="sidebar__title">Download</h3>
                                </div>
                                <div class="sidebar__download-list-box">
                                    <ul class="sidebar__download-list list-unstyled">
                                        <li>
                                            <a href="#">Download Doc<span class="icon-direct-download"></span></a>
                                        </li>
                                        <li>
                                            <a href="#">Download Pdf<span class="icon-download-pdf"></span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Service Details End-->


        <!--Site Footer Two Start-->
        <footer class="site-footer-two">
           @include('layouts.footer')
            <div class="site-footer-two__bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="site-footer-two__bottom-inner">
                                <div class="site-footer-two__copyright">
                                     <p class="site-footer-two__copyright-text">© 2025 <a href="#">Webmingo</a>
                                        All
                                        Rights Reserved.</p>
                                </div>
                                <div class="site-footer-two__bottom-menu-box">
                                    <ul class="list-unstyled site-footer-two__bottom-menu">
                                        <li><a href="about.html">Privacy Policy</a></li>
                                        <li><a href="about.html">Terms & Conditions</a></li>
                                        <li><a href="about.html">Customer Policy</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--Site Footer Two End-->




    </div><!-- /.page-wrapper -->


    <div class="mobile-nav__wrapper">
        <div class="mobile-nav__overlay mobile-nav__toggler"></div>
        <!-- /.mobile-nav__overlay -->
        <div class="mobile-nav__content">
            <span class="mobile-nav__close mobile-nav__toggler"><i class="fa fa-times"></i></span>

            <div class="logo-box">
                <a href="index.html" aria-label="logo image"><img src="assets/images/resources/logo-2.png" width="150"
                        alt="" /></a>
            </div>
            <!-- /.logo-box -->
            <div class="mobile-nav__container"></div>
            <!-- /.mobile-nav__container -->

            <ul class="mobile-nav__contact list-unstyled">
                <li>
                    <i class="fa fa-envelope"></i>
                    <a href="mailto:needhelp@packageName__.com">needhelp@givewell.com</a>
                </li>
                <li>
                    <i class="fas fa-phone"></i>
                    <a href="tel:666-888-0000">666 888 0000</a>
                </li>
            </ul><!-- /.mobile-nav__contact -->
            <div class="mobile-nav__top">
                <div class="mobile-nav__social">
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-facebook-square"></a>
                    <a href="#" class="fab fa-pinterest-p"></a>
                    <a href="#" class="fab fa-instagram"></a>
                </div><!-- /.mobile-nav__social -->
            </div><!-- /.mobile-nav__top -->



        </div>
        <!-- /.mobile-nav__content -->
    </div>
    <!-- /.mobile-nav__wrapper -->

    <div class="search-popup">
        <div class="search-popup__overlay search-toggler"></div>
        <!-- /.search-popup__overlay -->
        <div class="search-popup__content">
            <form action="#">
                <label for="search" class="sr-only">search here</label><!-- /.sr-only -->
                <input type="text" id="search" placeholder="Search Here..." />
                <button type="submit" aria-label="search submit" class="thm-btn">
                    <span class="fas fa-search"></span>
                </button>
            </form>
        </div>
        <!-- /.search-popup__content -->
    </div>
    <!-- /.search-popup -->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top">
        <span class="scroll-to-top__wrapper"><span class="scroll-to-top__inner"></span></span>
        <span class="scroll-to-top__text"> Go Back Top</span>
    </a>




   <script src="{{asset('admin/assets/js/jquery-latest.js')}}"></script>
    <script src="{{asset('admin/assets/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jarallax.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.ajaxchimp.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.appear.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/swiper.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.magnific-popup.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.validate.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/odometer.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/wNumb.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/wow.js')}}"></script>
    <script src="{{asset('admin/assets/js/isotope.js')}}"></script>
    <script src="{{asset('admin/assets/js/owl.carousel.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery-ui.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.nice-select.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.circleType.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.fittext.js')}}"></script>
    <script src="{{asset('admin/assets/js/jquery.lettering.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/vegas.min.js')}}"></script>
    <script src="{{asset('admin/assets/js/aos.js')}}"></script>
    <script src="{{asset('admin/assets/js/marquee.min.js')}}"></script>




    <script src="{{asset('admin/assets/js/gsap/gsap.js')}}"></script>
    <script src="{{asset('admin/assets/js/gsap/ScrollTrigger.js')}}"></script>
    <script src="{{asset('admin/assets/js/gsap/SplitText.js')}}"></script>




    <!-- template js -->
    <script src="{{asset('admin/assets/js/script.js')}}"></script>
</body>


<!-- Mirrored from html.scriptfusions.com/givewell/main-html/kids-education.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 17 Jul 2025 11:24:34 GMT -->
</html>
