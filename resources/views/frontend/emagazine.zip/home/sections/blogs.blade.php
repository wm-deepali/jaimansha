<!--Blog One Start -->
<section class="blog-one">
    <div class="blog-one__bg" style="background-image: url({{ asset('admin/assets/images/backgrounds/blog-one-bg.jpg') }});"></div>
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-6 col-md-8">
                <div class="blog-one__left">
                    <div class="section-title text-left sec-title-animation animation-style2">
                        <div class="section-title__tagline-box">
                            <div class="section-title__tagline-icon">
                                <i class="icon-like"></i>
                            </div>
                            <span class="section-title__tagline">Blog & Article</span>
                        </div>
                        <h2 class="section-title__title title-animation">Check Latests Blog Post</h2>
                    </div>
                    <div class="blog-one__newsletter">
                        <h4 class="blog-one__newsletter-title">Newsletter</h4>
                        <p class="blog-one__newsletter-text">Subscribe to receive news & updates.</p>
                        <form class="blog-one__newsletter-form">
                            <div class="blog-one__newsletter-input">
                                <input type="email" placeholder="Email Address">
                                <div class="blog-one__newsletter-input-icon">
                                    <span class="icon-mail"></span>
                                </div>
                            </div>
                            <div class="checked-box">
                                <input type="checkbox" name="skipper1" id="skipper" checked="">
                                <label for="skipper"><span></span>I agree the terms & Conditions</label>
                            </div>
                            <button type="submit" class="thm-btn blog-one__newsletter-btn">Subscribe Now
                                <span class="icon-arrow-right"></span>
                                <i></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-xl-8">
                <div class="blog-one__right">
                    <div class="blog-one__carousel owl-theme owl-carousel">
                        @foreach($blogs as $blog)
                        <!--Blog One Single Start -->
                        <div class="item">
                            <div class="blog-one__single">
                                <div class="blog-one__tag">
                                    <div class="blog-one__tag-icon">
                                        <span class="icon-folder"></span>
                                    </div>
                                    <p class="blog-one__tag-text">{{ $blog->title ?? 'Uncategorized' }}</p>
                                </div>
                                <div class="blog-one__img">
                                    <img src="{{ asset('admin/assets/images/blog/' . $blog->image) }}" alt="">
                                    <div class="blog-one__date">
                                        <h4>{{ \Carbon\Carbon::parse($blog->created_at)->format('d') }}</h4>
                                        <p>{{ \Carbon\Carbon::parse($blog->created_at)->format('M') }}</p>
                                    </div>
                                </div>
                                <div class="blog-one__content">
                                    <h3 class="blog-one__title">
                                        <a href="#">
                                            {{ $blog->meta_title }}
                                        </a>
                                    </h3>
                                    <div class="blog-one__shape">
                                        <img src="{{ asset('admin/assets/images/shapes/blog-one-shape-1.png') }}" alt="">
                                    </div>
                                    <p class="blog-one__text">
                                        {{ Str::limit($blog->meta_description, 100) }}
                                    </p>
                                    <div class="blog-one__user-and-btn-box">
                                        <div class="blog-one__user">
                                            <div class="blog-one__user-icon">
                                                <span class="icon-account"></span>
                                            </div>
                                            <p class="blog-one__user-text">{{ $blog->category->written_by ?? 'Admin' }}</p>
                                        </div>
                                        <div class="blog-one__btn-box">
                                            <a href="#" class="blog-one__btn thm-btn">
                                                More Details
                                                <span class="icon-arrow-right"></span><i></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Blog One Single End -->
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Blog One End -->
