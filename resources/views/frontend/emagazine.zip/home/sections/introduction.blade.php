
    <!--About One Start -->
       <section class="about-one">
           <div class="container">
               <div class="row">
                   <div class="col-xl-6">
                       <div class="about-one__left">
                           <div class="section-title text-left sec-title-animation animation-style2">
                               <div class="section-title__tagline-box">
                                   <div class="section-title__tagline-icon">
                                       <i class="icon-like"></i>
                                   </div>
                                   <span class="section-title__tagline">Introduction</span>
                               </div>
                               <h2 class="section-title__title title-animation">{{$latestIntroduction->heading}}</h2>
                           </div>
                           <p class="about-one__text">{{$latestIntroduction->detail_content}} </p>

                           <ul class="list-item row clearfix list-unstyled">
                               <li class="col-xl-6 col-lg-6 col-md-6">
                                   <div class="icon">
                                       <i class="icon-handshake"></i>
                                   </div>
                                   <div class="title count-box">
                                       <h4 class="count-text" data-stop="1200" data-speed="1500">00</h4>
                                       <h3>Volunteers</h3>
                                   </div>
                               </li>
                               <li class="col-xl-6 col-lg-6 col-md-6">
                                   <div class="icon">
                                       <i class="icon-growth"></i>
                                   </div>
                                   <div class="title count-box">
                                       <h4 class="count-text" data-stop="2200" data-speed="1500">00</h4>
                                       <h3>
                                           Trusted Funds
                                       </h3>
                                   </div>
                               </li>
                           </ul>
                           <ul class="about-one__mission-and-vision list-unstyled">
                               <li>
                                   <div class="about-one__icon-and-title">
                                       <div class="about-one__icon">
                                           <span class="icon-doctor"></span>
                                       </div>
                                       <h3>Our Mission:</h3>
                                   </div>
                                   <p class="about-one__mission-and-vision-text">
                                       {!! $latestIntroduction->visionAndMission->heading !!}
                                   </p>
                               </li>
                               <li>
                                   <div class="about-one__icon-and-title">
                                       <div class="about-one__icon">
                                           <span class="icon-team"></span>
                                       </div>
                                       <h3>Our Vision</h3>
                                   </div>
                                   <p class="about-one__mission-and-vision-text">
                                       {!! $latestIntroduction->visionAndMission->description !!}
                                   </p>
                               </li>
                           </ul>
                           <div class="about-one__btn-box">
                               <a href="about.html" class="about-one__btn thm-btn">Read More<span
                                       class="icon-arrow-right"></span><i></i></a>
                           </div>
                       </div>
                   </div>
                   <div class="col-xl-6">
                       <div class="about-one__right">
                           <div class="donation-form-one">
                               <div class="inner-title">
                                   <h3>Easy Donation</h3>
                               </div>
                               <form id="donation-form-one" name="donation_form-one" class="default-form2" action="#"
                                   method="post">
                                   <div class="form-group">
                                       <div class="input-box">
                                           <input type="text" name="form_name" id="formName" placeholder="Name...."
                                               required="">
                                       </div>
                                   </div>
                                   <div class="form-group">
                                       <div class="input-box">
                                           <input type="email" name="form_email" id="formEmail" placeholder="Email...."
                                               required="">
                                       </div>
                                   </div>
                                   <div class="form-group">
                                       <div class="select-box clearfix">
                                           <select class="wide">
                                               <option data-display="Select Sauses">Select Sauses</option>
                                               <option value="Charity For Food">Charity For Food</option>
                                               <option value="Charity For Education">Charity For Education</option>
                                               <option value="Charity For Water">Charity For Water</option>
                                               <option value="Charity For Natural Disaster">Charity For Natural
                                                   Disaster</option>
                                           </select>
                                       </div>
                                   </div>

                                   <div class="form-group">
                                       <label for="dallor1">Amount</label>
                                       <ul>
                                           <li>
                                               <input type="radio" id="dallor1" name="dallor" checked="checked">
                                               <label for="dallor1">
                                                   <i></i>
                                                   <span>$10</span>
                                               </label>
                                           </li>
                                           <li>
                                               <input type="radio" id="dallor2" name="dallor">
                                               <label for="dallor2">
                                                   <i></i>
                                                   <span>$20</span>
                                               </label>
                                           </li>
                                           <li>
                                               <input type="radio" id="dallor3" name="dallor">
                                               <label for="dallor3">
                                                   <i></i>
                                                   <span>$30</span>
                                               </label>
                                           </li>
                                           <li>
                                               <input type="radio" id="dallor4" name="dallor">
                                               <label for="dallor4">
                                                   <i></i>
                                                   <span>$40</span>
                                               </label>
                                           </li>
                                           <li>
                                               <input type="radio" id="dallor5" name="dallor">
                                               <label for="dallor5">
                                                   <i></i>
                                                   <span>$50</span>
                                               </label>
                                           </li>


                                       </ul>
                                   </div>

                                   <div class="form-group">
                                       <div class="input-box">
                                           <input type="text" name="form_amount" id="formAmount"
                                               placeholder="Custom Amount...." required="">
                                       </div>
                                   </div>

                                   <div class="form-group">
                                       <label for="donation1">Payment Method</label>
                                       <ul>
                                           <li>
                                               <input type="radio" id="donation1" name="donation" checked="checked">
                                               <label for="donation1">
                                                   <i></i>
                                                   <span>Test Donation</span>
                                               </label>
                                           </li>
                                           <li>
                                               <input type="radio" id="donation2" name="donation">
                                               <label for="donation2">
                                                   <i></i>
                                                   <span>Offline Donation</span>
                                               </label>
                                           </li>
                                           <li>
                                               <input type="radio" id="donation3" name="donation">
                                               <label for="donation3">
                                                   <i></i>
                                                   <span>Credit Card</span>
                                               </label>
                                           </li>
                                       </ul>
                                   </div>
                                   <div class="donation-form__btn-box">
                                       <button type="submit" class="thm-btn">
                                           Donate Now <span class="icon-arrow-right"></span><i></i>
                                       </button>
                                   </div>
                               </form>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </section>
       <!--About One End -->
