@extends('layouts.events_details')

@section('content')

   @include('events_details.sections.eventspageheader')

   @include('events_details.sections.eventsdetails')

@endsection
